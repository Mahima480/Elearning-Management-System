<?php
include("header.php");
include '1configtemp.php';
if(isset($_POST['submit'])){
$email=$_POST['email'];
$password=$_POST['password'];

$email_search ="select * from signup where email ='$email'";
$query =mysqli_query($con,$email_search);

$email_count=mysqli_num_rows($query);
if($email_count)
{
$email_pass= mysqli_fetch_assoc($query);
$db_pass=$email_pass['password'];
$_SESSION['username']=$email_pass['username'];

$pass_decode=password_verify($password,$db_pass);

 if($pass_decode)
 {
  
   
  
  
  ?>
<script>
alert("login successful");
header('location:home.php');
</script>
<?php


     

 }
   else{
     
     ?>
     <script>
     alert("password Incorrect");
     
     </script>
     <?php
     


     }
    }
     else
     {

      ?>
<script>
alert("Invalid Email");

</script>
<?php
       }
    }
?>
?>

<!-- start -->



<div class="register">



<form action="home.php" method="post" id="register">
<center><h1>Login Here</h1><br>

</center>


<label>Email Id:</label><br>
<input type="text" name="email" id="name" placeholder="Enter Your Email Id" required/>
<!-- <br><br> -->

<label>Password:</label><br>
<input type="password" name="password" id="name" placeholder="Enter Password" required/>
<!-- <br><br> -->
<br><br>
<input type="submit" value="Login" name="submit" id="submit">
<a href="home.php"><input type="button" value="<< --back" name="submit1" id="back">
</a>











</form>







</div>
<!-- end -->
<?php
include("footer.php");
?>
