<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
        
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">

    <link rel="stylesheet" href="../css/design.css">
</head>
<body>
<header>
    <div id="topHeader" class="p-1">
      <div class="container">
        <div class="row">
          <div class="col-12 text-right">
            <a href="tel:+6267313000" class="p-1"><i class="fas fa-phone"></i> +6267313000</a>
            <a href="mailto:+abc@gmail.com" class="p-1"><i class="fas fa-envelope"></i> +abc@gmail.com</a>

          </div>
        </div>
      </div>
    </div>

    <!-- #004d80; -->
    <div id="bottomHeader">
      <div class="container-fluid ">
        <nav class="navbar navbar-dark navbar-expand-md" style="background-color:#004d80; ">
          
          <a class="navbar-brand font-weight-bold " href="#">E-Learning</a> 
          
          <button data-toggle="collapse" data-target="#navbarToggler" type="button" class="navbar-toggler"><span class="navbar-toggler-icon"></span></button>
          <div class="collapse navbar-collapse" id="navbarToggler">
            <ul class="navbar-nav custom-nav">
              <li class="nav-item custom-nav-item">
                <a class="nav-link text-white " href="home.php">Home</a>
              </li>
              <li class="nav-item dropdown custom-nav-item">
                <a class="nav-link dropdown-toggle text-white " data-toggle="dropdown" role="button" href="#">Courses</a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="developnment.php">Developnment</a>
                    <a class="dropdown-item" href="design.php">Design</a>
                    <a class="dropdown-item" href="finance.php">Finance and Acounting</a>
                    <a class="dropdown-item" href="business.php">Business</a>
                    <a class="dropdown-item" href="it.php">IT and software</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="health.php">Health and Fitness</a>
                </div>
 
              <li class="nav-item custom-nav-item">
                <a class="nav-link text-white" href="contactus.php">Contact</a>
              </li>
              <li class="nav-item custom-nav-item">
                <a class="nav-link text-white" href="about us">About us</a>
              </li>
              <li class="nav-item custom-nav-item">
                <a class="nav-link text-white" href="login.php">Login</a>
              </li>
              <li class="nav-item custom-nav-item">
                <a class="nav-link text-white" href="signup1.php">Signup</a>
              </li>
              <li class="nav-item custom-nav-item">
                <a class="nav-link text-white" href="feedback.html">Feedback</a>
              </li>
            </ul>
          </div>
        </nav>
 
      </div>
    </div>
 
  </header>
<section class="breadcrumps-section">
<div class="container p-1 p-sm-3">
<div class="row">
<div class="col-12">
<h1 class="text-center" >HEALTH AND FITNESS</h1>


</div></div></div>
</section>

<section class="requirements-section pt-1 pb-1 pt-md-2 pb-md-2">
    <div class="container" style="background-color: #004d80;color:white;">
    <div class="row align-items-center">
    <div class="col-md-9">
    <h3>YOGA</h3>
    
    
    </div>
    
        </div></div>
    
</section>
<br><br><br>

<div class="container">
<div class="row">
<div class="col-sm-4">
<div class="card" style="width: 18rem;">
  <!-- <img class="card-img-top" src="..." alt="Card image cap"> -->
  <iframe  src="https://www.youtube.com/embed/395ZloN4Rr8" title="YouTube video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"  allowfullscreen ></iframe>
  <div class="card-body">
    <h5 class="card-title text-center">Pranayama</h5>
    <p class="card-text "></p>
    <a href="order.php?id=137&name=Pranayama&price=345" class="btn btn-primary">Enroll Now</a>
    <h5 class="text-right">
    <small>
    <s class="text-secondary">$456</s></small>
    <span class="price">$345</span>
    
    </h5>
  </div>
</div>
</div>

<div class="col-sm-4">
<div class="card" style="width: 18rem;">
<iframe  src="https://www.youtube.com/embed/VQkAT9Nc_vM" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
  <div class="card-body">
    <h5 class="card-title text-center">Face Yoga</h5>
    <p class="card-text"></p>
    <a href="order.php?id=138&name=face yoga&price=323" class="btn btn-primary">Enroll Now</a>
    <h5 class="text-right">
    <small>
    <s class="text-secondary">$564</s></small>
    <span class="price">$323</span>
    
    </h5>
  </div>
</div>
</div>

<div class="col-sm-4">
<div class="card" style="width: 18rem;">
<iframe  src="https://www.youtube.com/embed/ZToicYcHIOU"   allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
  <div class="card-body">
    <h5 class="card-title text-center">Meditation</h5>
    <p class="card-text"></p>
    <a href="order.php?id=139&name=Meditation&price=454" class="btn btn-primary">Enroll Now</a>
    <h5 class="text-right">
    <small>
    <s class="text-secondary">$654</s></small>
    <span class="price">$454</span>
    
    </h5>
  </div>
</div>
</div>



</div>
</div>
<br><br>


<section class="requirements-section pt-1 pb-1 pt-md-2 pb-md-2">
    <div class="container" style="background-color: #004d80;color:white;">
    <div class="row align-items-center">
    <div class="col-md-9">
    <h3>MENTAL HEALTH</h3>
    
    
    </div>
    
    
    </div></div>
    
</section>
<br><br><br>
<div class="container">
<div class="row">
<div class="col-sm-4">
<div class="card" style="width: 18rem;">
  <!-- <img class="card-img-top" src="..." alt="Card image cap"> -->
  <iframe  src="https://www.youtube.com/embed/q6aAQgXauQw" title="YouTube video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"  allowfullscreen ></iframe>
  <div class="card-body">
    <h5 class="card-title text-center">CBT</h5>
    <p class="card-text "></p>
    <a href="order.php?id=140&name=CBT&price=206" class="btn btn-primary">Enroll Now</a>
    <h5 class="text-right">
    <small>
    <s class="text-secondary">$435</s></small>
    <span class="price">$206</span>
    
    </h5>
  </div>
</div>
</div>

<div class="col-sm-4">
<div class="card" style="width: 18rem;">
<iframe  src="https://www.youtube.com/embed/2KXtlIX_yUs" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
  <div class="card-body">
    <h5 class="card-title text-center">PTSD</h5>
    <p class="card-text"></p>
    <a href="order.php?id=141&name=PTSD&price=240" class="btn btn-primary">Enroll Now</a>
    <h5 class="text-right">
    <small>
    <s class="text-secondary">$356</s></small>
    <span class="price">$240</span>
    
    </h5>
  </div>
</div>
</div>

<div class="col-sm-4">
<div class="card" style="width: 18rem;">
<iframe  src="https://www.youtube.com/embed/Vg8J1577Q3w"   allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
  <div class="card-body">
    <h5 class="card-title text-center">Art Therapy</h5>
    <p class="card-text"></p>
    <a href="order.php?id=142&name=Art therapy&price=419" class="btn btn-primary">Enroll Now</a>
    <h5 class="text-right">
    <small>
    <s class="text-secondary">$786</s></small>
    <span class="price">$419</span>
    
    </h5>
  </div>
</div>
</div>



</div>
</div>
<br><br>

<section class="requirements-section pt-1 pb-1 pt-md-2 pb-md-2">
    <div class="container" style="background-color: #004d80;color:white;">
    <div class="row align-items-center">
    <div class="col-md-9">
    <h3>SELF DEFENCE</h3>
    
    
    </div>
    
    
    </div></div>
    
</section>
<br><br><br>
<div class="container">
<div class="row">
<div class="col-sm-4">
<div class="card" style="width: 18rem;">
  <!-- <img class="card-img-top" src="..." alt="Card image cap"> -->
  <iframe  src="https://www.youtube.com/embed/7rWkE3vWc4s" title="YouTube video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"  allowfullscreen ></iframe>
  <div class="card-body">
    <h5 class="card-title text-center">Martial Arts</h5>
    <p class="card-text "></p>
    <a href="order.php?id=143&name=Martial Arts&price=319" class="btn btn-primary">Enroll Now</a>
    <h5 class="text-right">
    <small>
    <s class="text-secondary">$671</s></small>
    <span class="price">$319</span>
    
    </h5>
  </div>
</div>
</div>

<div class="col-sm-4">
<div class="card" style="width: 18rem;">
<iframe  src="https://www.youtube.com/embed/KVpxP3ZZtAc" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
  <div class="card-body">
    <h5 class="card-title text-center">Self Defence</h5>
    <p class="card-text"></p>
    <a href="order.php?id=144&name=Self Defence&price=749" class="btn btn-primary">Enroll Now</a>
    <h5 class="text-right">
    <small>
    <s class="text-secondary">$959</s></small>
    <span class="price">$749</span>
    
    </h5>
  </div>
</div>
</div>

<div class="col-sm-4">
<div class="card" style="width: 18rem;">
<iframe  src="https://www.youtube.com/embed/kKDHdsVN0b8"   allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
  <div class="card-body">
    <h5 class="card-title text-center">Boxing</h5>
    <p class="card-text"></p>
    <a href="order.php?id=145&name=boxing&price=619" class="btn btn-primary">Enroll Now</a>
    <h5 class="text-right">
    <small>
    <s class="text-secondary">$789</s></small>
    <span class="price">$619</span>
    
    </h5>
  </div>
</div>
</div>



</div>
</div>
<br><br>
















<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
   <script src="js/signup.js"></script>   
</body>
</html>