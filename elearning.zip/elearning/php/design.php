<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
        
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">

    <link rel="stylesheet" href="../css/design.css">
</head>
<body>
<header>
    <div id="topHeader" class="p-1">
      <div class="container">
        <div class="row">
          <div class="col-12 text-right">
            <a href="tel:+6267313000" class="p-1"><i class="fas fa-phone"></i> +6267313000</a>
            <a href="mailto:+abc@gmail.com" class="p-1"><i class="fas fa-envelope"></i> +abc@gmail.com</a>

          </div>
        </div>
      </div>
    </div>

    <!-- #004d80; -->
    <div id="bottomHeader">
      <div class="container-fluid ">
        <nav class="navbar navbar-dark navbar-expand-md" style="background-color:#004d80; ">
          
          <a class="navbar-brand font-weight-bold " href="#">E-Learning</a> 
          
          <button data-toggle="collapse" data-target="#navbarToggler" type="button" class="navbar-toggler"><span class="navbar-toggler-icon"></span></button>
          <div class="collapse navbar-collapse" id="navbarToggler">
            <ul class="navbar-nav custom-nav">
              <li class="nav-item custom-nav-item">
                <a class="nav-link text-white " href="home.php">Home</a>
              </li>
              <li class="nav-item dropdown custom-nav-item">
                <a class="nav-link dropdown-toggle text-white " data-toggle="dropdown" role="button" href="#">Courses</a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="developnment.php">Developnment</a>
                    <a class="dropdown-item" href="design.php">Design</a>
                    <a class="dropdown-item" href="finance.php">Finance and Acounting</a>
                    <a class="dropdown-item" href="business.php">Business</a>
                    <a class="dropdown-item" href="it.php">IT and software</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="health.php">Health and Fitness</a>
                </div>
 
              <li class="nav-item custom-nav-item">
                <a class="nav-link text-white" href="contactus.php">Contact</a>
              </li>
              <li class="nav-item custom-nav-item">
                <a class="nav-link text-white" href="about us">About us</a>
              </li>
              <li class="nav-item custom-nav-item">
                <a class="nav-link text-white" href="login.php">Login</a>
              </li>
              <li class="nav-item custom-nav-item">
                <a class="nav-link text-white" href="signup1.php">Signup</a>
              </li>
              <li class="nav-item custom-nav-item">
                <a class="nav-link text-white" href="feedback.html">Feedback</a>
              </li>
            </ul>
          </div>
        </nav>
 
      </div>
    </div>
 
  </header>
<section class="breadcrumps-section">
<div class="container p-1 p-sm-3">
<div class="row">
<div class="col-12">
<h1 class="text-center" >DESIGN</h1>


</div></div></div>
</section>

<section class="requirements-section pt-1 pb-1 pt-md-2 pb-md-2">
    <div class="container" style="background-color: #004d80;color:white;">
    <div class="row align-items-center">
    <div class="col-md-9">
    <h3>WEB DESIGN</h3>
    
    
    </div>
    
    
    </div></div>
    
</section>
<br><br><br>

<div class="container">
<div class="row">
<div class="col-sm-4">
<div class="card" style="width: 18rem;">
  <!-- <img class="card-img-top" src="..." alt="Card image cap"> -->
  <iframe  src="https://www.youtube.com/embed/8AZ8GqW5iak" title="YouTube video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"  allowfullscreen ></iframe>
  <div class="card-body">
    <h5 class="card-title text-center">Wordpress</h5>
    <p class="card-text "></p>
    <a href="order.php?id=128&name=Wordpress&price=645" class="btn btn-primary">Enroll Now</a>
    <h5 class="text-right">
    <small>
    <s class="text-secondary">$789</s></small>
    <span class="price">$645</span>
    
    </h5>
  </div>
</div>
</div>

<div class="col-sm-4">
<div class="card" style="width: 18rem;">
<iframe  src="https://www.youtube.com/embed/yfoY53QXEnI" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
  <div class="card-body">
    <h5 class="card-title text-center">Cascading Style Sheet</h5>
    <p class="card-text"></p>
    <a href="order.php?id=129&name=CSS&price=179" class="btn btn-primary">Enroll Now</a>
    <h5 class="text-right">
    <small>
    <s class="text-secondary">$919</s></small>
    <span class="price">$179</span>
    
    </h5>
  </div>
</div>
</div>

<div class="col-sm-4">
<div class="card" style="width: 18rem;">
<iframe  src="https://www.youtube.com/embed/UB1O30fR-EE"   allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
  <div class="card-body">
    <h5 class="card-title text-center">HTML</h5>
    <p class="card-text"></p>
    <a href="order.php?id=130&name=HTML&price=385" class="btn btn-primary">Enroll Now</a>
    <h5 class="text-right">
    <small>
    <s class="text-secondary">$567</s></small>
    <span class="price">$385</span>
    
    </h5>
  </div>
</div>
</div>



</div>
</div>
<br><br>


<section class="requirements-section pt-1 pb-1 pt-md-2 pb-md-2">
    <div class="container" style="background-color: #004d80;color:white;">
    <div class="row align-items-center">
    <div class="col-md-9">
    <h3>GRAPHIC DESIGN</h3>
    
    
    </div>
    
    
    </div></div>
    
</section>
<br><br><br>
<div class="container">
<div class="row">
<div class="col-sm-4">
<div class="card" style="width: 18rem;">
  <!-- <img class="card-img-top" src="..." alt="Card image cap"> -->
  <iframe  src="https://www.youtube.com/embed/pFyOznL9UvA" title="YouTube video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"  allowfullscreen ></iframe>
  <div class="card-body">
    <h5 class="card-title text-center">Photoshop</h5>
    <p class="card-text "></p>
    <a href="order.php?id=131&name=photoshop&price=319" class="btn btn-primary">Enroll Now</a>
    <h5 class="text-right">
    <small>
    <s class="text-secondary">$419</s></small>
    <span class="price">$319</span>
    
    </h5>
  </div>
</div>
</div>

<div class="col-sm-4">
<div class="card" style="width: 18rem;">
<iframe  src="https://www.youtube.com/embed/0dqhpLRPkRY" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
  <div class="card-body">
    <h5 class="card-title text-center">Canva</h5>
    <p class="card-text"></p>
    <a href="order.php?id=132&name=Canva&price=329" class="btn btn-primary">Enroll Now</a>
    <h5 class="text-right">
    <small>
    <s class="text-secondary">$429</s></small>
    <span class="price">$329</span>
    
    </h5>
  </div>
</div>
</div>

<div class="col-sm-4">
<div class="card" style="width: 18rem;">
<iframe  src="https://www.youtube.com/embed/vd1vRpoWC3M"   allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
  <div class="card-body">
    <h5 class="card-title text-center">Adobe Illustrator</h5>
    <p class="card-text"></p>
    <a href="order.php?id=133&name=Adobe&price=519" class="btn btn-primary">Enroll Now</a>
    <h5 class="text-right">
    <small>
    <s class="text-secondary">$867</s></small>
    <span class="price">$519</span>
    
    </h5>
  </div>
</div>
</div>



</div>
</div>
<br><br>

<section class="requirements-section pt-1 pb-1 pt-md-2 pb-md-2">
    <div class="container" style="background-color: #004d80;color:white;">
    <div class="row align-items-center">
    <div class="col-md-9">
    <h3>INTERIOR DESIGN</h3>
    
    
    </div>
    
    
    </div></div>
    
</section>
<br><br><br>
<div class="container">
<div class="row">
<div class="col-sm-4">
<div class="card" style="width: 18rem;">
  <!-- <img class="card-img-top" src="..." alt="Card image cap"> -->
  <iframe  src="https://www.youtube.com/embed/qgt2s9RzvKM" title="YouTube video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"  allowfullscreen ></iframe>
  <div class="card-body">
    <h5 class="card-title text-center">Sketch up</h5>
    <p class="card-text "></p>
    <a href="order.php?id=134&name=Sketchup&price=519" class="btn btn-primary">Enroll Now</a>
    <h5 class="text-right">
    <small>
    <s class="text-secondary">$956</s></small>
    <span class="price">$519</span>
    
    </h5>
  </div>
</div>
</div>

<div class="col-sm-4">
<div class="card" style="width: 18rem;">
<iframe  src="https://www.youtube.com/embed/xouTvTzIAlQ" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
  <div class="card-body">
    <h5 class="card-title text-center">Colour Theory</h5>
    <p class="card-text"></p>
    <a href="order.php?id=135&name=Colour theory&price=213" class="btn btn-primary">Enroll Now</a>
    <h5 class="text-right">
    <small>
    <s class="text-secondary">$563</s></small>
    <span class="price">$213</span>
    
    </h5>
  </div>
</div>
</div>

<div class="col-sm-4">
<div class="card" style="width: 18rem;">
<iframe  src="https://www.youtube.com/embed/4ORbpY6d9Zk"   allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
  <div class="card-body">
    <h5 class="card-title text-center">Lighting Design</h5>
    <p class="card-text"></p>
    <a href="order.php?id=136&name=Lighting Design&price=749" class="btn btn-primary">Enroll Now</a>
    <h5 class="text-right">
    <small>
    <s class="text-secondary">945</s></small>
    <span class="price">$749</span>
    
    </h5>
  </div>
</div>
</div>



</div>
</div>
<br><br>
















<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
   <script src="js/signup.js"></script>   
</body>
</html>