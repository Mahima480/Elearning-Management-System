<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
        
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">

    <link rel="stylesheet" href="../css/signup.css">
</head>
<body>


<?php
include '1configtemp.php';
if(isset($_POST['submit'])){
$username=mysqli_real_escape_string($con ,$_POST['username']);
$email=mysqli_real_escape_string($con, $_POST['email']);
$mobile=mysqli_real_escape_string($con, $_POST['mobile']);
$password=mysqli_real_escape_string($con, $_POST['password']);
$cpassword=mysqli_real_escape_string($con, $_POST['cpassword']);

$pass=password_hash($password,PASSWORD_BCRYPT);
$cpass=password_hash($cpassword,PASSWORD_BCRYPT);

$emailquery ="select * from signup where email ='$email'  ";
$query =mysqli_query($con,$emailquery);

$emailcount=mysqli_num_rows($query);
if($emailcount>0)
{
    
    ?>
<script>
alert("Email already exist");
</script>
<?php

}else{
    if($password === $cpassword)
    {
        $insertquery="insert into signup(username,email,mobile,password,cpassword) values('$username','$email','$mobile','$pass','$cpass') ";
        $iquery=mysqli_query($con,$insertquery);

        if($iquery)
{
?>
<script>
alert("Inserted Successfully");
</script>
<?php

}
else
{
?>
<script>
alert(" Not Inserted");
</script>
<?php
}



        
    }else{
        ?>
<script>
alert(" password not matching ");
</script>
<?php

        
    }
}



    
}







?>








<div class="main">
<!-- start -->
<div class="register">
<!-- <h2>Register Here</h2> -->

<form action="" method="post" id="register">
<center><h1>Register Here</h1><br>

</center>
<label> Name:</label>
<input type="text" name="username" id="name" placeholder="Enter Your  Name" required/>


<label>Email Id:</label><br>
<input type="text" name="email" id="name" placeholder="Enter Your Email Id" required/>
<!-- <br><br> -->

<label>Phone Number:</label><br>
<input type="number" name="mobile" id="name" placeholder="Enter Your Phone Number" required/>

<label>Password:</label><br>
<input type="password" name="password" id="name" placeholder="Enter Password" required/>

<label>Confirm Password:</label><br>
<input type="password" name="cpassword" id="name" placeholder="Confirm Password" required/>
<!-- <br><br> -->
<br><br>
<input type="submit" value="Submit" name="submit" id="submit">
<a href="home.php"><input type="button" value="<< --back" name="submit1" id="back">
</a>
</form>
















</div>
 <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
   <script src="js/signup.js"></script>   
</body>
</html>