<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
        
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">

        
        

        <link rel="stylesheet" href="../css/home.css" type="text/css">
</head>
<body>
<header>
    <div id="topHeader" class="p-1">
      <div class="container">
        <div class="row">
          <div class="col-12 text-right">
            <a href="tel:+6267313000" class="p-1"><i class="fas fa-phone"></i> +6267313000</a>
            <a href="mailto:+abc@gmail.com" class="p-1"><i class="fas fa-envelope"></i> +abc@gmail.com</a>

          </div>
        </div>
      </div>
    </div>

    <!-- #004d80; -->
    <div id="bottomHeader">
      <div class="container-fluid ">
        <nav class="navbar navbar-dark navbar-expand-md" style="background-color:#004d80; ">
          
          <a class="navbar-brand font-weight-bold " href="#">E-Learning</a> 
          
          <button data-toggle="collapse" data-target="#navbarToggler" type="button" class="navbar-toggler"><span class="navbar-toggler-icon"></span></button>
          <div class="collapse navbar-collapse" id="navbarToggler">
            <ul class="navbar-nav custom-nav">
              <li class="nav-item custom-nav-item">
                <a class="nav-link text-white " href="home.php">Home</a>
              </li>
              <li class="nav-item dropdown custom-nav-item">
                <a class="nav-link dropdown-toggle text-white " data-toggle="dropdown" role="button" href="#">Courses</a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="developnment.php">Developnment</a>
                    <a class="dropdown-item" href="design.php">Design</a>
                    <a class="dropdown-item" href="finance.php">Finance and Acounting</a>
                    <a class="dropdown-item" href="business.php">Business</a>
                    <a class="dropdown-item" href="it.php">IT and software</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="health.php">Health and Fitness</a>
                </div>
 
              <li class="nav-item custom-nav-item">
                <a class="nav-link text-white" href="contactus.php">Contact</a>
              </li>
              
              <li class="nav-item custom-nav-item">
                <a class="nav-link text-white" href="login.php">Login</a>
              </li>
              <li class="nav-item custom-nav-item">
                <a class="nav-link text-white" href="signup1.php">Signup</a>
              </li>
              <li class="nav-item custom-nav-item">
                <a class="nav-link text-white" href="feedback.html">Feedback</a>
              </li>
            </ul>
          </div>
        </nav>
 
      </div>
    </div>
 
  </header>

  <!-- End header part  -->
  <!-- start carosel part  -->
   <section>
    <div class="container-fluid">
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="../image/change.jpg" alt="First slide" height="400">

      <!-- <div class="carousel-caption d-none d-md-block">
             <h1 Class="font-weight-bolder p-5" style="color:#ecf0f1">HOME SERVICES</h1>
            <p   Class="font-weight-bold p-2">Our website  will provide a platform for all kind of house hold services at any time and place</p>
    </div> -->
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="../image/2replace2.jpg" alt="Second slide" height="400">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="../image/3replace.cms" alt="Third slide" height="400">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>




     
    </div>
  </section>


   <!-- next section -->
    <section class="pt-4 pb-1">
    <div class="container">
    <div class="row">
    <div class="col-12 text-center">
    <h1 style="color:#004d80;">Categories</h1>
    <hr>
    </div>
    
    </div>

    
    <div class="row">
    <div class="col-md-3 text-center p-4">
    <img src="../image/design1.jpg" class="img-fluid " alt="">
    <h5>Design</h5>
    <p class="text-justify ">Some popular specialisations/ branches in which students can take a design course are :
     Fashion Design Graphic Design Interior Design etc
    </p>
    
    

    
    </div>
    <div class="col-md-3 text-center  p-4">
    <img src="../image/developnment1.jpg"  class="img-fluid" alt="">
    <h5>Developnment</h5>
    <p class="text-justify ">Developnment courses includes web developnment data science programming languages etc</p>
    
    
    </div>
    <div class="col-md-3 text-center  p-4">
    <img src="../image/finance.jpg"  class="img-fluid" alt="">
    <h5>Finance And Accounting</h5>
    <p class="text-justify ">Studying finance helps you train and prepare for a business career and develops business awareness.</p>
    
    
    </div>
    <div class="col-md-3 text-center  p-4">
    <img src="../image/marketing.jpg"  class="img-fluid" alt="">
    <h5>Marketing</h5>
    <p class="text-justify ">Marketing studies can help students to become professionals in the industry,
     teaching them how to run businesses successfully .
</p>

    
    </div>
    
    
    
    </div>
    <div class="row">
    <div class="col-md-3 text-center  p-4">
    <img src="../image/personality1.jpg"   class="img-fluid" alt="">
    <h5>Personality</h5>
    <p class="text-justify  ">This course covers various dimensions and importance of effective personality. ...
     Soft skills comprise pleasant and appealing personality</p>
    

    
    </div>
    <div class="col-md-3 text-center  p-4">
    <img src="../image/health.jpg"   class="img-fluid" alt="">
    <h5>Health and Fitness</h5>
    <p class="text-justify  ">fitness being so important to personal health and life satisfaction.It includes mental health yoga nutrition sports diet
    dance  etc</p>
    
    </div>
    <div class="col-md-3 text-center  p-4">
    <img src="../image/software1.jpg"   class="img-fluid" alt="">
    <h5>IT and Software</h5>
    <p class="text-justify ">These courses includes Operating System,IT certification,Network Security,Hardware etc</p>
    
    </div>
    <div class="col-md-3 text-center  p-4">
    <img src="../image/business1.jpg"   class="img-fluid" alt="">
    <h5>Business</h5>
    <p class="text-justify "> business operations as well as gaining targeted skills in your specific
     field, such as customers, markets, finance, operations, strategy </p>
    
    </div>
    
    
    
    </div>
    </div></section>



    <section class="requirements-section pt-1 pb-1 pt-md-2 pb-md-2">
    <div class="container" style="background-color: #004d80;color:white;">
    <div class="row align-items-center">
    <div class="col-md-9">
    <h3>Do you have any requirement? we can do it for you</h3>
    
    
    </div>
    <div class="col-md-3">
    <button class="btn btn-lg btn-primary" >Get Started</button>
    
    
    
    </div>
    
    
    </div></div>
</section>

<Section class="top-sc  pb-5 pt-5" >
    <div class="container " >
    <div class="row align-items-center">
    <div class="col-md-6">
    <a id="a"><h2 class="font-weight-bold" >About E-Learning</h2></a>
    <hr>
    <h6  style="word-spacing:15px " class="text-justify font-weight-bold">We believe
Learning is the source of human progress.

It has the power to transform our world
from illness to health,
from poverty to prosperity,
from conflict to peace.


No matter who we are or where we are,
learning empowers us to change

And that’s why E-learning is here.
We partner with the best institutions
to bring the best learning
to every corner of the world.

So that anyone, anywhere has the power to
transform their life through learning.
</h6><br>
    <button style="color:white ; background-color:#004d80" class="btn btn-lg btn-primary">Search Here</button>

    
    </div>
    <div class=" col-md-6" >
    <img src="../image/side.jpg" alt="" class="img-fluid "height="500"  width="500">
    
    
    
    </div>
    
    
    </div></div>
    </Section>




    <footer class="full-footer pt-md-5 pb-md-5">
    <div class="container top-footer">
      <div class="row">
        <div class="col-md-3 ">

          <h3 class="font-weight-bold">Get In Touch</h3>
          <h6 class="text-light font-weight-bold">Don’t Miss To Follow Us On Our Social Networks Accounts.
          </h6>
          <a href="https://www.facebook.com" style="color: white ;" class="p-1"> <i class="fab fa-2x fa-facebook"></i></a>
          <a href="https://www.twitter.com" style="color: white;" class="p-1"> <i class="fab fa-2x fa-twitter"></i></a>
          <a href="https://www.instagram.com" style="color: white ;" class="p-1"> <i class=" fab fa-2x fa-instagram"></i></a>
          <a href="https://www.google.com" style="color: white;" class="p-1"><i class="fab  fa-2x fa-google-plus-square"></i></a>



        </div>
        <div class="col-md-3">
          <h3 class="font-weight-bold">Categories</h3>
        <a href="">Developnment</a></br>
        <a href="">Design</a></br>
        <a href="">It and Software</a></br>
        <a href="">Business</a></br>
        <a href="">Finance And Accounting</a></br>
        <a href="">Health and Fitness</a></br>
        <a href="">Marketing</a></br>
        <a href="">Personality</a></br>
        


          
        </div>
        <div class="col-md-3 Kite"  >
          <h3 class="text-light font-weight-bold" >Quick Links</h3>
          <a href="">Signup</a></br>
        <a href="">login</a></br>
        <a href="">Feedback</a></br>
        <a href="">Courses</a></br>
        <a href="">Contact us</a></br>
       
          <!-- <h6 class="text-light" >About Us</h6>
          <h6 class="text-light">Contact Us</h6>
          <h6 class="text-light">Courses</h6>
          <h6 class="text-light" >Login</h6>
          <h6 class="text-light">Signup</h6> -->

</div>

        <div class="col-md-3 Kite"  >
          <h3 class="text-light font-weight-bold" >Contact us</h3>
          
</div>
    </div>
  



  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"
        crossorigin="anonymous"></script>

    <!-- Option 2: jQuery, Popper.js, and Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    



    
    



    
</body>
</html>