<?php

$server="localhost";
$username="root";
$password="";
$database="elearning";
$conn=mysqli_connect($server,$username,$password,$database);
$showalert=false;
if($_SERVER['REQUEST_METHOD'] == "POST")
{
    $name=$_POST["name"];
    $email=$_POST["email"];
    $address=$_POST["address"];
    $mobile=$_POST["mob"];
    $sql="INSERT INTO `message` (`name`, `email`, `address`, `mobile`) VALUES ( '$name', '$email', '$address', '$mobile');";
    $result=mysqli_query($conn,$sql);
    if($result){
        $showalert=true;
    }
    
}


?>






<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <title>Contact US</title>
    <link rel="stylesheet" href="a.css">
    <style>
         .back{
             background:transparent;
         }
         #heading{
             margin-left: 20px;
             margin-top: 10px;
         }
        </style>
</head>

<body>
<header>
    <div id="topHeader" class="p-1">
      <div class="container">
        <div class="row">
          <div class="col-12 text-right">
            <a href="tel:+6267313000" class="p-1"><i class="fas fa-phone"></i> +6267313000</a>
            <a href="mailto:+abc@gmail.com" class="p-1"><i class="fas fa-envelope"></i> +abc@gmail.com</a>

          </div>
        </div>
      </div>
    </div>

    <!-- #004d80; -->
    <div id="bottomHeader">
      <div class="container-fluid ">
        <nav class="navbar navbar-dark navbar-expand-md" style="background-color:#004d80; ">
          
          <a class="navbar-brand font-weight-bold " href="#">E-Learning</a> 
          
          <button data-toggle="collapse" data-target="#navbarToggler" type="button" class="navbar-toggler"><span class="navbar-toggler-icon"></span></button>
          <div class="collapse navbar-collapse" id="navbarToggler">
            <ul class="navbar-nav custom-nav">
              <li class="nav-item custom-nav-item">
                <a class="nav-link text-white " href="home.php">Home</a>
              </li>
              <li class="nav-item dropdown custom-nav-item">
                <a class="nav-link dropdown-toggle text-white " data-toggle="dropdown" role="button" href="#">Courses</a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="developnment.php">Developnment</a>
                    <a class="dropdown-item" href="design.php">Design</a>
                    <a class="dropdown-item" href="finance.php">Finance and Acounting</a>
                    <a class="dropdown-item" href="business.php">Business</a>
                    <a class="dropdown-item" href="it.php">IT and software</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="health.php">Health and Fitness</a>
                </div>
 
              <li class="nav-item custom-nav-item">
                <a class="nav-link text-white" href="contactus.php">Contact us</a>
              </li>
              <li class="nav-item custom-nav-item">
                <a class="nav-link text-white" href="about us">About us</a>
              </li>
              <li class="nav-item custom-nav-item">
                <a class="nav-link text-white" href="login.php">Login</a>
              </li>
              <li class="nav-item custom-nav-item">
                <a class="nav-link text-white" href="signup1.php">Signup</a>
              </li>
              <li class="nav-item custom-nav-item">
                <a class="nav-link text-white" href="feedback.html">Feedback</a>
              </li>
            </ul>
          </div>
        </nav>
 
      </div>
    </div>
 
  </header>
    <div class="card bg-dark text-white" id= "contact">
        <img src="digital+marketing+contractor.jpg" class="card-img" alt="..." >
        <div class="card-img-overlay">
            <?php
                if($showalert)
                {
                    echo'<div class="alert alert-warning alert-dismissible fade show" role="alert">
           <strong>Success !! </strong> '. ' Your data is Added Successfully !!
           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
             <span aria-hidden="true">&times;</span>
           </button>
         </div>';
                }
            ?>
            <h2 class="card-title"id="heading">WE'll Contact you!!</h2>
           <br>
           

            <div class="row ">
                <div class="col-sm-5">
                    <div class="card back">
                        <div class="card-body">
                            <form action=""method="post">
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Name</label>
                                    <input type="text" class="form-control" id=""placeholder="Enter your name"name="name">
                                  </div>
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Email address</label>
                                  <input type="email" class="form-control" id="" aria-describedby="emailHelp"placeholder=" Enter your Email Address "name="email">
                                  <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Address</label>
                                    <input type="text" class="form-control" id=""placeholder="Makan no., current address"name="address">
                                  </div>
                                  <div class="form-group">
                                    <label for="exampleInputPassword1">Mobile No.</label>
                                    <input type="text" class="form-control" id=""placeholder="Enter your Contact Number"name="mob">
                                  </div>
                                <center>
                                <!-- <button type="submit" class="btn btn-lg-warning">send</button> -->
                                <button type="submit" class="btn btn-outline-info btn-lg";>Send</button>
                                </center>
                              </form>
                            
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"
        crossorigin="anonymous"></script>

    <!-- Option 2: jQuery, Popper.js, and Bootstrap JS
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    -->
</body>

</html>